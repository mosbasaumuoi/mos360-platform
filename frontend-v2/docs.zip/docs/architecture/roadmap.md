FILE 6 — /docs/architecture/roadmap.md
MOS360 Roadmap
PHASE A — Runtime Convergence
Mục tiêu
unify runtime ownership
stabilize lifecycle
freeze SPA shell
build bridge architecture
runtime islands foundation.
PHASE B — Content Operating System
Mục tiêu
import thật
validation thật
runtime content store
authoring runtime
publish pipeline.
PHASE C — Human Experience
Mục tiêu
completion psychology
continuity feeling
confidence loop
legitimacy reinforcement
employability flow.
PHASE D — Internal Beta
Mục tiêu
real learners
telemetry thật
completion metrics
retention metrics
runtime stability.
LONG TERM

MOS360 evolve thành:
Learning Runtime Operating Platform